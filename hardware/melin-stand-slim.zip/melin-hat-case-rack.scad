// ============================================================================
//  MELIN HAT CASE RACK — modular, stackable, slide-in shelf system
// ----------------------------------------------------------------------------
//  Designed around the Melin 3-Hat Travel Case (published dims 250 x 200 x
//  150 mm). The sloped lid means these can't be stacked directly — this rack
//  gives every case its own slide-in bay, with only ~11.5 mm of vertical
//  overhead per case (floor + rails + lid clearance).
//
//  Each module is one bay. Modules stack via tapered pegs/sockets at the four
//  corner columns — print as many as you need and grow the tower over time.
//  An optional top cap ties the uppermost pegs together and gives a flat top.
//
//  BAMBU LAB H2D NOTES
//  - Footprint ~222 x 258 mm, height ~168 mm w/ pegs: fits the bed in either
//    nozzle mode (350x320 single / 300x320 dual), one module per plate.
//  - Print in the modeled orientation (floor on bed). ZERO supports needed:
//    every feature is vertical, chamfered, ramped, or a short bridge.
//  - Socket pockets bridge ~10 mm at z≈6.5 mm — trivial for the H2D.
//  - Suggested: PETG-HF or PLA Basic, 0.4 mm nozzle, 0.2 mm layers,
//    3 walls, 10–15% infill, no brim needed (huge first layer).
//  - Print the "fit_test" part FIRST (~10 min) to dial in fit_clear for
//    your filament before committing to a full module.
//
//  PARTS (set `part` below or use the customizer):
//    rack          - one stackable bay (print one per case)
//    top_cap       - optional lid frame for the top of the stack
//    fit_test      - small peg + socket coupon to verify fit_clear
//    stack_preview - visual: two bays stacked with ghost cases
//
//  TIP: to slide cases in wide-side-first instead (shallower, wider rack),
//  just swap the case_l and case_w values.
// ============================================================================

/* [Part selection] */
part = "rack"; // [rack, top_cap, fit_test, stack_preview]

/* [Case dimensions (Melin 3-Hat Travel Case)] */
// Depth the case slides in (mm)
case_l = 250;
// Case width across the opening (mm)
case_w = 200;
// Case height at the tallest point of the lid (mm)
case_h = 150;

/* [Fit & clearance] */
// Side clearance per side between case and walls
side_clear = 3.0;
// Clearance above the lid peak (zipper pulls need room)
top_clear = 6.0;
// Peg/socket clearance per side — tune with the fit_test part
fit_clear = 0.20;

/* [Structure] */
// Floor thickness
floor_t = 3.0;
// Side wall thickness
wall_t = 3.0;
// Side wall height (guides the case, keeps plastic low)
wall_h = 30;
// Leg cross-section across the width (protrusion beyond wall = post_x - wall_t)
post_x = 8;
// Leg cross-section along the depth (deep blade profile for stiffness)
post_y = 26;
// Length of full-height wall "towers" fused to each column
tower_l = 20;
// Back stop thickness
back_t = 3.0;
// Extra floor in front of the case
front_margin = 5.0;
// Slide rail height (case rides on rails, not the floor)
rail_h = 2.5;
// Slide rail width
rail_w = 7.0;
// Number of slide rails
n_rails = 3;
// Outer rail inset from the inner wall face
rail_margin = 20;
// Finger notch radius at the front edge
notch_r = 28;
// Cut lightening slots in the floor between rails
lighten = true;
// Add soft detent bumps so cases don't creep out
detent = true;
// Detent bump height
detent_h = 1.2;

/* [Stacking joint] */
// Peg base footprint, blade oriented along the depth
peg_bx = 4.0;
peg_by = 16.0;
// Peg tip footprint (taper for easy engagement)
peg_tx = 2.5;
peg_ty = 13.0;
// Peg height
peg_h = 6.0;
// Extra socket depth so pegs always seat fully
socket_extra = 0.5;

/* [Top cap] */
// Cap plate thickness
cap_t = 4.0;
// Cap frame band width
cap_band = 26;

/* [Headroom branding] */
// Wordmark text
brand_text = "HEADROOM";
// raised = embossed on outer walls, inset = engraved, off = plain
brand_mode = "raised"; // [raised, inset, off]
// Emboss/engrave depth
brand_depth = 0.6;
// Letter cap height (mm)
brand_size = 13;
// Font (any installed font works; swap for your brand font)
brand_font = "Liberation Sans:style=Bold";
// Letter spacing multiplier for a wide, infrastructure-grade look
brand_spacing = 1.25;

/* [Hidden] */
$fn = 64;
eps = 0.01;

// ---------------------------------------------------------------------------
// Derived dimensions
// ---------------------------------------------------------------------------
inner_w  = case_w + 2 * side_clear;                 // slide channel width
depth    = back_t + case_l + front_margin;          // overall depth (Y)
pitch    = floor_t + rail_h + case_h + top_clear;   // vertical stack pitch
col_h    = pitch;                                   // column height
env_w    = inner_w + 2 * post_x;                    // overall width (X)

// Corner leg centers [x, y]
col_pos = [
    [-(inner_w / 2 + post_x / 2), post_y / 2],
    [ (inner_w / 2 + post_x / 2), post_y / 2],
    [-(inner_w / 2 + post_x / 2), depth - post_y / 2],
    [ (inner_w / 2 + post_x / 2), depth - post_y / 2]
];

rail_span = inner_w - 2 * rail_margin;
rail_x = (n_rails == 1) ? [0] :
    [ for (i = [0 : n_rails - 1]) -rail_span / 2 + i * rail_span / (n_rails - 1) ];

echo(str("=== MELIN RACK: footprint ", env_w, " x ", depth,
         " mm (legs protrude ", post_x - wall_t, " mm past walls) | pitch ", pitch, " mm | print height ",
         col_h + peg_h, " mm ==="));

// ---------------------------------------------------------------------------
// Primitives
// ---------------------------------------------------------------------------
module rect_frustum(bx, by, tx, ty, h)
    linear_extrude(height = h, scale = [tx / bx, ty / by])
        square([bx, by], center = true);

module peg() rect_frustum(peg_bx, peg_by, peg_tx, peg_ty, peg_h);

// Socket void — same taper as the peg, opened up by fit_clear per side,
// oriented to be carved upward from z = 0 (the underside of the module).
module socket_void()
    translate([0, 0, -eps])
        rect_frustum(peg_bx + 2 * fit_clear, peg_by + 2 * fit_clear,
                     peg_tx + 2 * fit_clear, peg_ty + 2 * fit_clear,
                     peg_h + socket_extra + eps);

module rrect(w, l, r)
    offset(r = r) offset(r = -r) square([w, l], center = true);

// ---------------------------------------------------------------------------
// Headroom branding
// ---------------------------------------------------------------------------
module brand_2d(sz)
    text(brand_text, size = sz, font = brand_font, spacing = brand_spacing,
         halign = "center", valign = "center");

// Wordmark on both outer side walls, centered along the depth.
// raised=true builds proud text (union), raised=false builds the cutter
// volume for engraving (difference). Prints support-free either way.
module wall_brand(raised) {
    ox = inner_w / 2 + wall_t;   // outer wall face
    d  = brand_depth;
    zc = wall_h / 2;
    yc = depth / 2;
    // Right wall, reads correctly from +X
    translate([raised ? ox - 0.1 : ox - d, yc, zc])
        rotate([90, 0, 90]) linear_extrude(d + 0.1) brand_2d(brand_size);
    // Left wall, reads correctly from -X
    translate([raised ? -(ox - 0.1) : -(ox - d), yc, zc])
        rotate([90, 0, -90]) linear_extrude(d + 0.1) brand_2d(brand_size);
}

// One slide rail with a 45-degree lead-in ramp at the front so the case
// noses in smoothly. Rails near the finger notch stop short of it.
module rail(x) {
    is_short = abs(x) < notch_r + rail_w;
    y0 = back_t;
    y1 = is_short ? depth - notch_r - 6 : depth - 2;
    ramp = 8;
    translate([x - rail_w / 2, 0, floor_t]) {
        translate([0, y0, 0])
            cube([rail_w, (y1 - ramp) - y0, rail_h]);
        hull() {
            translate([0, y1 - ramp, 0]) cube([rail_w, eps, rail_h]);
            translate([0, y1 - eps, 0]) cube([rail_w, eps, 0.6]);
        }
    }
}

// ---------------------------------------------------------------------------
// Main stackable bay
// ---------------------------------------------------------------------------
module rack() {
    difference() {
        union() {
            // Floor — main plate between the walls
            translate([-(inner_w / 2 + wall_t), 0, 0])
                cube([inner_w + 2 * wall_t, depth, floor_t]);

            // Floor — corner pads under the columns
            for (p = col_pos)
                translate([p[0] - post_x / 2, p[1] - post_y / 2, 0])
                    cube([post_x, post_y, floor_t]);

            // Side walls + full-height towers at each end
            for (s = [-1, 1]) {
                wx = (s == -1) ? -(inner_w / 2 + wall_t) : inner_w / 2;
                translate([wx, 0, 0]) cube([wall_t, depth, wall_h]);
                translate([wx, 0, 0]) cube([wall_t, tower_l, col_h]);
                translate([wx, depth - tower_l, 0])
                    cube([wall_t, tower_l, col_h]);
            }

            // Back stop
            translate([-(inner_w / 2 + wall_t), 0, 0])
                cube([inner_w + 2 * wall_t, back_t, wall_h]);

            // Corner columns + stacking pegs
            for (p = col_pos) {
                translate([p[0] - post_x / 2, p[1] - post_y / 2, 0])
                    cube([post_x, post_y, col_h]);
                translate([p[0], p[1], col_h]) peg();
            }

            // Slide rails
            for (x = rail_x) rail(x);

            // Retention detents on the outer rails, near the front
            if (detent && n_rails >= 2)
                for (x = [rail_x[0], rail_x[n_rails - 1]])
                    translate([x, depth - 16, floor_t + rail_h])
                        scale([2, 4, 1]) sphere(r = detent_h);

            // Embossed wordmark
            if (brand_mode == "raised") wall_brand(true);
        }

        // Finger notch at the front center
        translate([0, depth, -eps])
            cylinder(r = notch_r, h = floor_t + rail_h + 2 * eps);

        // Stacking sockets under each column
        for (p = col_pos)
            translate([p[0], p[1], 0]) socket_void();

        // 45-degree lead-in chamfers at the front opening (sized to clear
        // the front leg sockets/pegs: nearest socket vertex sits 6.6 mm
        // from the corner in diamond metric vs 4.95 mm chamfer reach)
        for (s = [-1, 1])
            translate([s * inner_w / 2, depth, -eps])
                rotate([0, 0, 45])
                    translate([-3.5, -3.5, 0])
                        cube([7, 7, col_h + peg_h + 2 * eps]);

        // Lightening slots in the floor between rails
        if (lighten && n_rails >= 2)
            for (i = [0 : n_rails - 2]) {
                gap_c = (rail_x[i] + rail_x[i + 1]) / 2;
                gap_w = abs(rail_x[i + 1] - rail_x[i]) - rail_w - 16;
                slot_l = case_l - 90;
                if (gap_w > 20)
                    translate([gap_c, back_t + 20 + slot_l / 2, -eps])
                        linear_extrude(floor_t + 2 * eps)
                            rrect(gap_w, slot_l, 8);
            }

        // Engraved wordmark
        if (brand_mode == "inset") wall_brand(false);
    }
}

// ---------------------------------------------------------------------------
// Top cap — printed pocket-side UP, installed flipped onto the top pegs
// ---------------------------------------------------------------------------
module top_cap() {
    boss_h  = peg_h + socket_extra + 1.5;
    pocket  = peg_h + socket_extra;
    difference() {
        union() {
            // Perimeter frame
            linear_extrude(cap_t)
                difference() {
                    translate([0, depth / 2]) rrect(env_w, depth, 8);
                    translate([0, depth / 2])
                        rrect(env_w - 2 * cap_band, depth - 2 * cap_band, 8);
                }
            // Cross bar for stiffness
            translate([-env_w / 2, depth / 2 - 12, 0])
                cube([env_w, 24, cap_t]);
            // Corner bosses
            for (p = col_pos)
                translate([p[0] - post_x / 2, p[1] - post_y / 2, 0])
                    cube([post_x, post_y, cap_t + boss_h]);
        }
        // Pockets — wide at the (printed) top, so when the cap is flipped
        // in use they taper exactly like the module sockets
        for (p = col_pos)
            translate([p[0], p[1], cap_t + boss_h - pocket])
                rect_frustum(peg_tx + 2 * fit_clear, peg_ty + 2 * fit_clear,
                             peg_bx + 2 * fit_clear, peg_by + 2 * fit_clear,
                             pocket + eps);

        // Inlaid wordmark on the crossbar. This face prints ON the bed,
        // so the engraving comes out dead crisp, and reads correctly once
        // the cap is flipped onto the stack. Paint the recessed letters
        // in Bambu Studio for a two-tone finish with the second nozzle.
        if (brand_mode != "off")
            translate([0, depth / 2, -eps])
                linear_extrude(brand_depth + eps)
                    mirror([1, 0, 0]) brand_2d(brand_size);
    }
}

// ---------------------------------------------------------------------------
// Fit test — tiny peg tile + socket block, replicates real print geometry
// ---------------------------------------------------------------------------
module fit_test() {
    // Peg tile
    translate([-14, 0, 0]) {
        translate([-7, -15, 0]) cube([14, 30, 3]);
        translate([0, 0, 3]) peg();
    }
    // Socket block — same cross-section as a real leg, so the socket
    // walls and bed-facing bridge print exactly like the module
    translate([14, 0, 0])
        difference() {
            translate([-post_x / 2, -post_y / 2, 0])
                cube([post_x, post_y, 10]);
            socket_void();
        }
}

// ---------------------------------------------------------------------------
// Preview — two bays stacked, ghost cases in place
// ---------------------------------------------------------------------------
module stack_preview() {
    for (i = [0, 1]) translate([0, 0, i * pitch]) rack();
    %for (i = [0, 1])
        translate([-case_w / 2, back_t, floor_t + rail_h + i * pitch])
            cube([case_w, case_l, case_h]);
}

// ---------------------------------------------------------------------------
if (part == "rack")           rack();
else if (part == "top_cap")   top_cap();
else if (part == "fit_test")  fit_test();
else                          stack_preview();
